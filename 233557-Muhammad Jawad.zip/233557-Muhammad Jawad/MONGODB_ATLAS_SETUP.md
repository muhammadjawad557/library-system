# 🔧 MongoDB Atlas Setup Guide

Complete guide to set up MongoDB Atlas for the Smart Library System.

---

## 📋 Prerequisites

- Email address (for MongoDB account)
- Internet connection
- Project ready to connect

---

## 🚀 Step-by-Step Setup

### Step 1: Create MongoDB Atlas Account

1. Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
2. Click **"Try Free"** or **"Sign Up"**
3. Create account with:
   - Email & Password, OR
   - Google Account, OR
   - GitHub Account
4. Verify your email address

---

### Step 2: Create a New Cluster

1. **After login**, you'll see "Create a cluster" page
2. Choose **FREE** tier (M0 Sandbox)
   - ✅ 512 MB storage
   - ✅ Shared RAM
   - ✅ Perfect for learning

3. **Cloud Provider & Region:**
   - Provider: AWS (recommended)
   - Region: Choose closest to your location
   - ✅ Look for "FREE TIER AVAILABLE" label

4. **Cluster Name:**
   - Default: `Cluster0`
   - Or custom name: `SmartLibraryCluster`

5. Click **"Create Cluster"**
   - ⏱️ Takes 3-7 minutes to provision

---

### Step 3: Configure Database Access

#### Create Database User

1. Click **"Database Access"** in left sidebar
2. Click **"Add New Database User"**
3. Configure user:
   ```
   Username: library_admin
   Password: [Generate secure password]
   ```
   - 💡 **IMPORTANT:** Save this password securely!
   - Click "Autogenerate Secure Password" for strong password

4. **Database User Privileges:**
   - Select: **"Read and write to any database"**
   - Role: `readWriteAnyDatabase`

5. Click **"Add User"**

---

### Step 4: Configure Network Access

#### Add IP Address

1. Click **"Network Access"** in left sidebar
2. Click **"Add IP Address"**
3. Choose one option:

   **Option A: Allow from Anywhere** (Development)
   ```
   IP Address: 0.0.0.0/0
   Description: Allow from anywhere
   ```
   - ⚠️ **Note:** Only for development. Not for production!

   **Option B: Add Your Current IP** (Recommended)
   - Click "Add Current IP Address"
   - Your IP will be auto-detected

4. Click **"Confirm"**
5. Wait for status to change to **"Active"**

---

### Step 5: Get Connection String

1. Go to **"Database"** in left sidebar
2. Find your cluster (e.g., `Cluster0`)
3. Click **"Connect"** button
4. Select **"Connect your application"**
5. Choose:
   - **Driver:** Node.js
   - **Version:** 4.1 or later

6. **Copy the connection string:**
   ```
   mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```

---

### Step 6: Configure Connection String

#### Replace Placeholders

Original:
```
mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
```

After replacement:
```
mongodb+srv://library_admin:YOUR_PASSWORD_HERE@cluster0.xxxxx.mongodb.net/smart-library?retryWrites=true&w=majority
```

**Important Changes:**
1. Replace `<username>` with: `library_admin`
2. Replace `<password>` with: Your actual password (from Step 3)
3. Add database name after `.net/`: `/smart-library`

#### Example:
```
mongodb+srv://library_admin:MySecurePass123@cluster0.mongodb.net/smart-library?retryWrites=true&w=majority
```

---

### Step 7: Update `.env` File

1. Navigate to `server` folder
2. Open `.env` file
3. Update `MONGODB_URI`:

```env
# MongoDB Atlas Connection String
MONGODB_URI=mongodb+srv://library_admin:YOUR_PASSWORD_HERE@cluster0.xxxxx.mongodb.net/smart-library?retryWrites=true&w=majority

# Server Configuration
PORT=5000
NODE_ENV=development
```

4. **Save the file**

---

### Step 8: Test Connection

#### Start Backend Server

```bash
cd server
npm start
```

#### Expected Output:
```
✅ MongoDB Atlas Connected: cluster0-shard-00-00.xxxxx.mongodb.net
📚 Database: smart-library
🔗 Mongoose connected to MongoDB Atlas
🚀 Smart Library System Backend Server
📡 Server running on port: 5000
```

#### If Successful:
- ✅ You'll see green checkmarks
- ✅ Database name displayed
- ✅ Server running

#### If Failed:
- ❌ Check username/password
- ❌ Verify IP whitelist
- ❌ Ensure cluster is active
- ❌ Check internet connection

---

## 🗄️ Database Structure

After first book is added, you'll see:

### Database: `smart-library`
```
Collections:
├── books (auto-created)
│   ├── Document 1
│   │   ├── _id: ObjectId
│   │   ├── title: String
│   │   ├── author: String
│   │   ├── isbn: String
│   │   ├── year: Number
│   │   ├── createdAt: Date
│   │   └── updatedAt: Date
│   └── Document 2...
```

---

## 🔍 View Data in Atlas

1. Go to MongoDB Atlas Dashboard
2. Click **"Browse Collections"**
3. Select database: `smart-library`
4. Select collection: `books`
5. See all your books!

---

## 🛠️ Common Issues & Solutions

### Issue 1: "MongoNetworkError"
**Cause:** IP not whitelisted

**Solution:**
1. Go to Network Access
2. Add your current IP
3. Wait for "Active" status

---

### Issue 2: "Authentication failed"
**Cause:** Wrong username/password

**Solution:**
1. Check `.env` file
2. Verify username: `library_admin`
3. Verify password (no extra spaces)
4. Regenerate password if needed

---

### Issue 3: "Could not connect to any servers"
**Cause:** Cluster not ready or wrong connection string

**Solution:**
1. Check cluster status (green = ready)
2. Verify connection string format
3. Ensure `/smart-library` is included

---

### Issue 4: "Database name not specified"
**Cause:** Missing database name in connection string

**Solution:**
Add `/smart-library` after `.mongodb.net`:
```
.mongodb.net/smart-library?retryWrites=true
```

---

## 📊 Monitoring

### View Metrics

1. Go to Atlas Dashboard
2. Click **"Metrics"** tab
3. Monitor:
   - Connections
   - Operations per second
   - Data size
   - Network traffic

---

## 💰 Free Tier Limits

| Resource | Limit |
|----------|-------|
| Storage | 512 MB |
| RAM | Shared |
| Connections | 500 |
| Backups | None |
| Cost | **FREE** ✅ |

**Perfect for:**
- ✅ Learning & Development
- ✅ Small projects
- ✅ Testing
- ✅ Prototypes

---

## 🔒 Security Best Practices

1. **Never commit `.env` file**
   - Already in `.gitignore`
   - Use `.env.example` for sharing

2. **Use strong passwords**
   - Min 12 characters
   - Include special characters
   - Auto-generate recommended

3. **Restrict IP access**
   - Production: Specific IPs only
   - Development: Your IP or VPN

4. **Regular password rotation**
   - Change every 90 days
   - Update `.env` file

---

## 🚀 Production Deployment

When deploying to production:

1. **Change IP Whitelist:**
   - Remove `0.0.0.0/0`
   - Add production server IP

2. **Use Environment Variables:**
   - Never hardcode credentials
   - Use hosting platform's env vars

3. **Enable Monitoring:**
   - Set up alerts
   - Monitor performance

---

## 📞 Support

**MongoDB Atlas Support:**
- Documentation: https://docs.atlas.mongodb.com/
- Community Forums: https://www.mongodb.com/community/forums/
- Stack Overflow: Tag `mongodb-atlas`

**Issues with this project?**
- Check console logs
- Verify all steps above
- Review error messages

---

## ✅ Quick Checklist

Before starting the server:

- [ ] MongoDB Atlas account created
- [ ] Cluster provisioned (green status)
- [ ] Database user created
- [ ] Password saved securely
- [ ] IP address whitelisted
- [ ] Connection string copied
- [ ] `.env` file updated with connection string
- [ ] `/smart-library` added to connection string
- [ ] Username/password replaced in connection string
- [ ] No spaces in `.env` values
- [ ] Backend dependencies installed (`npm install`)

---

## 🎉 Success!

If everything works:
- ✅ Backend connects to MongoDB Atlas
- ✅ Books can be added
- ✅ Data persists in cloud
- ✅ Can view data in Atlas dashboard

**You're ready to use the Smart Library System!** 🚀📚

---

**Last Updated:** January 1, 2026
