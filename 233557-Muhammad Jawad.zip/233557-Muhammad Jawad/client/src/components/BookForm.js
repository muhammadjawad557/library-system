import React, { useState } from 'react';
import * as Label from '@radix-ui/react-label';
import * as Toast from '@radix-ui/react-toast';
import './BookForm.css';

const BookForm = ({ onAddBook }) => {
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    isbn: '',
    publicationYear: ''
  });
  const [toastOpen, setToastOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.title || !formData.author || !formData.isbn || !formData.publicationYear) {
      setToastMessage('Please fill in all fields');
      setToastOpen(true);
      return;
    }

    // Call parent callback
    onAddBook(formData);

    // Show success message
    setToastMessage('Book added successfully! 📚');
    setToastOpen(true);

    // Reset form
    setFormData({
      title: '',
      author: '',
      isbn: '',
      publicationYear: ''
    });
  };

  return (
    <Toast.Provider swipeDirection="right">
      <div className="book-form-container">
        <h2>Add New Book</h2>
        <form onSubmit={handleSubmit} className="book-form">
          <div className="form-group">
            <Label.Root htmlFor="title" className="form-label">
              Book Title *
            </Label.Root>
            <input
              type="text"
              id="title"
              name="title"
              value={formData.title}
              onChange={handleChange}
              placeholder="Enter book title"
              className="form-input"
              required
            />
          </div>

          <div className="form-group">
            <Label.Root htmlFor="author" className="form-label">
              Author Name *
            </Label.Root>
            <input
              type="text"
              id="author"
              name="author"
              value={formData.author}
              onChange={handleChange}
              placeholder="Enter author name"
              className="form-input"
              required
            />
          </div>

          <div className="form-group">
            <Label.Root htmlFor="isbn" className="form-label">
              ISBN Number *
            </Label.Root>
            <input
              type="text"
              id="isbn"
              name="isbn"
              value={formData.isbn}
              onChange={handleChange}
              placeholder="Enter ISBN number"
              className="form-input"
              required
            />
          </div>

          <div className="form-group">
            <Label.Root htmlFor="publicationYear" className="form-label">
              Publication Year *
            </Label.Root>
            <input
              type="number"
              id="publicationYear"
              name="publicationYear"
              value={formData.publicationYear}
              onChange={handleChange}
              placeholder="Enter publication year"
              min="1000"
              max="2100"
              className="form-input"
              required
            />
          </div>

          <button type="submit" className="submit-btn">
            Add Book
          </button>
        </form>
      </div>

      <Toast.Root className="toast-root" open={toastOpen} onOpenChange={setToastOpen}>
        <Toast.Title className="toast-title">{toastMessage}</Toast.Title>
        <Toast.Close aria-label="Close" className="toast-close">
          <span aria-hidden>×</span>
        </Toast.Close>
      </Toast.Root>
      <Toast.Viewport className="toast-viewport" />
    </Toast.Provider>
  );
};

export default BookForm;
