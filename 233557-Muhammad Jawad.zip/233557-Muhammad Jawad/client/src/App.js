/**
 * Smart Library System - Main Application Component
 * 
 * Task 3: Error Handling & Code Comments (10 Marks)
 * - Implements user-friendly error messages
 * - Includes meaningful comments explaining key logic
 * - Handles backend connection issues gracefully
 */

import React, { useState, useEffect } from 'react';
import './App.css';
import BookForm from './components/BookForm';
import BookList from './components/BookList';

function App() {
  // State Management
  const [books, setBooks] = useState([]);        // Stores all books from database
  const [loading, setLoading] = useState(true);  // Loading state for initial fetch
  const [error, setError] = useState(null);      // Error messages for user feedback

  /**
   * Backend API Configuration
   * Task 3: Integration with backend server
   * Points to Node.js/Express server running on port 5000
   */
  const API_URL = 'http://localhost:5000/api/books';

  /**
   * Fetch Books on Component Mount
   * Task 1c: useEffect Hook (State Handling - 10 Marks)
   * Automatically fetches all books when component loads
   */
  useEffect(() => {
    fetchBooks();
  }, []); // Empty dependency array = run once on mount

  /**
   * Fetch all books from backend database
   * Task 2b: GET request to REST API (20 Marks)
   * Task 3: Error Handling with try-catch blocks
   * 
   * @returns {Promise<void>}
   */
  const fetchBooks = async () => {
    try {
      // Task 2b: GET request to backend API
      const response = await fetch(API_URL);

      // Check if request was successful
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      // Parse JSON response
      const result = await response.json();
      const booksData = result.data || result;
      
      // Task 1c: Update state dynamically
      setBooks(booksData);
      setError(null);
      
      console.log(`✅ Fetched ${booksData.length} books from database`);
    } catch (err) {
      // Task 3: User-friendly error message
      console.error('❌ Error fetching books:', err.message);
      
      // Display friendly error message to user
      setError('Unable to connect to server. Please ensure the backend is running on port 5000.');
      
      // Fallback: Start with empty array if backend unavailable
      setBooks([]);
    } finally {
      // Always set loading to false, regardless of success or failure
      setLoading(false);
    }
  };

  /**
   * Add new book to database
   * Task 1c: Dynamic UI Updates (State Handling - 10 Marks)
   * Task 3: Error Handling with user-friendly messages
   * 
   * @param {Object} bookData - Book information (title, author, isbn, year)
   * @returns {Promise<void>}
   */
  const handleAddBook = async (bookData) => {
    try {
      // Task 2b: POST request to backend API
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json', // Specify JSON content
        },
        body: JSON.stringify(bookData), // Convert object to JSON string
      });

      // Check if request was successful
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to add book to database');
      }

      // Parse response to get the created book with database ID
      const result = await response.json();
      const newBook = result.data || result;
      
      // Task 1c: Update state dynamically without page reload
      setBooks(prev => [...prev, newBook]);
      
      // Clear any previous errors
      setError(null);
      
      console.log(`✅ Book added successfully: ${newBook.title}`);
    } catch (err) {
      // Task 3: Display user-friendly error message
      console.error('❌ Error adding book:', err.message);
      
      // Show specific error to user
      setError(`Failed to add book: ${err.message}`);
      
      // Fallback: Add book locally if backend is unavailable
      const localBook = { 
        ...bookData, 
        _id: Date.now().toString(),
        createdAt: new Date().toISOString()
      };
      setBooks(prev => [...prev, localBook]);
      
      // Notify user about local storage
      setTimeout(() => {
        setError('Book added locally. It will sync when server is available.');
      }, 100);
    }
  };

  /**
   * Delete book from database
   * Task 1c: Dynamic UI Updates (State Handling - 10 Marks)
   * Task 3: Error Handling with user-friendly messages
   * 
   * @param {String} bookId - MongoDB ObjectId of the book to delete
   * @returns {Promise<void>}
   */
  const handleDeleteBook = async (bookId) => {
    try {
      // Task 2b: DELETE request to backend API
      const response = await fetch(`${API_URL}/${bookId}`, {
        method: 'DELETE',
      });

      // Check if deletion was successful
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to delete book from database');
      }

      // Task 1c: Update state dynamically without page reload
      setBooks(prev => prev.filter(book => book._id !== bookId));
      
      // Clear any previous errors
      setError(null);
      
      console.log(`✅ Book deleted successfully: ${bookId}`);
    } catch (err) {
      // Task 3: Display user-friendly error message
      console.error('❌ Error deleting book:', err.message);
      
      // Show specific error to user
      setError(`Failed to delete book: ${err.message}`);
      
      // Fallback: Delete book locally if backend is unavailable
      setBooks(prev => prev.filter(book => book._id !== bookId));
      
      // Notify user about local deletion
      setTimeout(() => {
        setError('Book deleted locally. Change will sync when server is available.');
      }, 100);
    }
  };

  /**
   * Render Application UI
   * Task 1a: React SPA Architecture (15 Marks)
   * - Component-based structure
   * - Props passing to child components
   * - Conditional rendering based on state
   */
  return (
    <div className="App">
      {/* Header Section */}
      <header className="app-header">
        <h1>📚 Smart Library System</h1>
        <p>Manage your book collection efficiently</p>
      </header>

      {/* Error Banner - Task 3: User-friendly error messages */}
      {error && (
        <div className="error-banner">
          <p>⚠️ {error}</p>
        </div>
      )}

      {/* Loading State */}
      {loading ? (
        <div className="loading">Loading books...</div>
      ) : (
        /* Main Content Area */
        <main className="app-main">
          {/* Task 1a: BookForm Component with props */}
          <BookForm onAddBook={handleAddBook} />
          
          {/* Task 1a: BookList Component with props */}
          <BookList books={books} onDeleteBook={handleDeleteBook} />
        </main>
      )}

      {/* Footer Section */}
      <footer className="app-footer">
        <p>Smart Library System © 2026</p>
      </footer>
    </div>
  );
}

export default App;
