# 🏗️ Component Architecture Diagram

## React Component Hierarchy

```
App (Main Component)
├── State Management
│   ├── books: []           (useState)
│   ├── loading: true       (useState)
│   └── error: null         (useState)
│
├── Effects
│   └── useEffect()         (Fetch books on mount)
│
├── Event Handlers
│   ├── handleAddBook()     (Add new book to list)
│   └── handleDeleteBook()  (Remove book from list)
│
└── Component Tree
    ├── Header
    │   ├── Title: "Smart Library System"
    │   └── Subtitle
    │
    ├── Error Banner (conditional)
    │   └── Warning message
    │
    ├── Loading State (conditional)
    │   └── "Loading books..."
    │
    └── Main Content
        ├── BookForm
        │   ├── Props IN:
        │   │   └── onAddBook (callback)
        │   │
        │   ├── Local State:
        │   │   └── formData (useState)
        │   │       ├── title
        │   │       ├── author
        │   │       ├── isbn
        │   │       └── publicationYear
        │   │
        │   ├── Form Fields:
        │   │   ├── Book Title Input
        │   │   ├── Author Name Input
        │   │   ├── ISBN Number Input
        │   │   └── Publication Year Input
        │   │
        │   └── Submit Button
        │       └── handleSubmit()
        │           ├── Validate inputs
        │           ├── Call onAddBook(formData)
        │           └── Reset form
        │
        └── BookList
            ├── Props IN:
            │   ├── books (array)
            │   └── onDeleteBook (callback)
            │
            ├── Conditional Rendering:
            │   ├── If books.length === 0
            │   │   └── Show "No books" message
            │   │
            │   └── Else
            │       └── Render book grid
            │
            └── Book Grid
                └── Map over books
                    └── BookCard (each book)
                        ├── Book Title
                        ├── Author Info
                        ├── ISBN Info
                        ├── Publication Year
                        └── Delete Button
                            └── onClick: onDeleteBook(book.id)
```

---

## Data Flow Diagram

```
┌─────────────────────────────────────────────────────────┐
│                       App Component                      │
│                                                          │
│  State: books = []                                       │
│  State: loading = true                                   │
│  State: error = null                                     │
└─────────────────────────────────────────────────────────┘
                    │           ▲
                    │           │
        ┌───────────┴───────┬───┴──────────┐
        │                   │              │
        ▼                   │              ▼
┌───────────────┐          │      ┌──────────────┐
│   BookForm    │          │      │   BookList   │
│               │          │      │              │
│ Props:        │          │      │ Props:       │
│ - onAddBook   │          │      │ - books      │
│               │          │      │ - onDeleteBook│
│ State:        │          │      │              │
│ - formData    │          │      └──────────────┘
└───────────────┘          │
        │                  │
        │ User fills form  │
        │ & clicks submit  │
        │                  │
        ▼                  │
┌───────────────────────┐  │
│ handleSubmit()        │  │
│ 1. Validate           │  │
│ 2. Call onAddBook()   │──┘ (Updates App state)
│ 3. Reset form         │
└───────────────────────┘
                          
        ▲
        │ User clicks delete
        │
┌───────────────────────┐
│ Delete Button         │
│ onClick: onDeleteBook │──┐
└───────────────────────┘  │
                           │
                           ▼
                    ┌──────────────────┐
                    │ handleDeleteBook │
                    │ Updates App state│
                    │ (filters books)  │
                    └──────────────────┘
```

---

## State Flow

### Adding a Book:

```
1. User enters data in BookForm
   ↓
2. formData state updates (onChange)
   ↓
3. User clicks "Add Book"
   ↓
4. BookForm validates inputs
   ↓
5. BookForm calls onAddBook(formData)
   ↓
6. App.handleAddBook() executes
   ↓
7. App sends POST request to backend
   ↓
8. App updates books state
   ↓
9. React re-renders BookList
   ↓
10. New book appears in UI
   ↓
11. BookForm resets
```

### Deleting a Book:

```
1. User clicks "Delete Book" button
   ↓
2. BookList calls onDeleteBook(bookId)
   ↓
3. App.handleDeleteBook() executes
   ↓
4. App sends DELETE request to backend
   ↓
5. App filters books array
   ↓
6. React re-renders BookList
   ↓
7. Book disappears from UI
```

---

## Component Responsibilities

### App.js (Container Component)
**Responsibilities:**
- Manage global state (books, loading, error)
- Fetch data from backend (useEffect)
- Handle business logic
- Coordinate between components
- API communication

**Does NOT:**
- Render form fields directly
- Style individual components
- Manage form state

---

### BookForm.js (Presentation Component)
**Responsibilities:**
- Render form UI
- Manage form input state
- Validate form data
- Handle form submission
- Reset form after submission

**Does NOT:**
- Know about the books array
- Make API calls
- Update parent state directly

---

### BookList.js (Presentation Component)
**Responsibilities:**
- Render book grid/cards
- Display book information
- Handle empty state
- Trigger delete action

**Does NOT:**
- Fetch data
- Manage books state
- Make API calls
- Know how to add books

---

## Props vs State

### Props (Data passed DOWN)
```javascript
// From App to BookForm
<BookForm onAddBook={handleAddBook} />

// From App to BookList
<BookList 
  books={books} 
  onDeleteBook={handleDeleteBook} 
/>
```

### State (Data managed LOCALLY)
```javascript
// In App.js
const [books, setBooks] = useState([]);
const [loading, setLoading] = useState(true);

// In BookForm.js
const [formData, setFormData] = useState({
  title: '',
  author: '',
  isbn: '',
  publicationYear: ''
});
```

---

## API Integration Points

```
App Component
    │
    ├── useEffect (on mount)
    │   └── GET /api/books
    │       └── setBooks(data)
    │
    ├── handleAddBook
    │   └── POST /api/books
    │       └── setBooks([...books, newBook])
    │
    └── handleDeleteBook
        └── DELETE /api/books/:id
            └── setBooks(books.filter(...))
```

---

## CSS Architecture

```
Global Styles (index.css)
├── Reset styles
├── Base typography
└── Minimum width (320px)

App Styles (App.css)
├── Layout structure
├── Header styling
├── Footer styling
├── Background gradient
└── Responsive breakpoints

BookForm Styles (BookForm.css)
├── Form container
├── Input fields
├── Submit button
├── Focus states
└── Mobile responsive

BookList Styles (BookList.css)
├── Grid layout
├── Card styling
├── Delete button
├── Hover effects
└── Mobile responsive
```

---

## Responsive Breakpoints

```
Mobile First Approach:

Base (320px+)
    ↓
Small Phones (480px+)
    ↓
Large Phones (600px+)
    ↓
Tablets (768px+)
    ↓
Desktop (1024px+)
```

---

## React Hooks Usage

### useState
```javascript
// Local state in components
const [value, setValue] = useState(initialValue);

// Used in:
- App.js: books, loading, error
- BookForm.js: formData
```

### useEffect
```javascript
// Side effects
useEffect(() => {
  // Effect code
}, [dependencies]);

// Used in:
- App.js: Fetch books on component mount
```

---

## Event Flow

### Form Submission:
```
Input onChange 
  → Update formData state
  → User submits
  → Validate
  → Call parent callback
  → Parent updates global state
  → Re-render children
  → Reset form
```

### Delete Action:
```
Click Delete Button
  → Call parent callback with ID
  → Parent filters state
  → Re-render children
  → Book removed from UI
```

---

## Component Communication

```
Parent → Child: Props
Child → Parent: Callback functions

Example:
┌─────────────┐
│     App     │
│             │
│ handleAdd   │───┐
└─────────────┘   │
                  │ Pass as prop
                  ▼
            ┌──────────────┐
            │   BookForm   │
            │              │
            │ onAddBook    │←── Received as prop
            │              │
            │ When submit  │───┐
            │ calls it     │   │ Call parent function
            └──────────────┘   │
                               │
                               ▼
                         ┌──────────────┐
                         │ Function     │
                         │ executes in  │
                         │ parent scope │
                         └──────────────┘
```

---

## File Dependencies

```
index.js
  └── App.js
      ├── App.css
      ├── BookForm.js
      │   └── BookForm.css
      └── BookList.js
          └── BookList.css
```

---

This architecture demonstrates:
✅ Component separation
✅ Unidirectional data flow
✅ Props drilling
✅ State management
✅ React Hooks
✅ Event handling
✅ Responsive design
✅ Modular CSS
