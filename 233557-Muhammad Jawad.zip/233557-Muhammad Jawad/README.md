# 📚 Smart Library System

A full-stack MERN (MongoDB, Express, React, Node.js) application for managing a library's book collection with modern UI and RESTful API.

## 🌟 Features

- Add, view, and delete books
- Responsive design (320px+)
- MongoDB Atlas cloud database
- RESTful API with Express
- Modern UI with Radix UI components

## 🚀 Technology Stack

- **Frontend:** React 19.2, Radix UI, CSS3
- **Backend:** Node.js, Express 4.18
- **Database:** MongoDB Atlas, Mongoose 8.0

## 📁 Project Structure

```
smart_library_system/
├── client/           # Frontend (React)
│   ├── src/
│   ├── public/
│   └── package.json
├── server/           # Backend (Node.js + Express)
│   ├── config/
│   ├── models/
│   ├── routes/
│   └── server.js
└── README.md
```

## 🔧 Installation

### Backend Setup

```bash
cd server
npm install
```

Configure `.env`:
```
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/smart-library
PORT=5000
```

### Frontend Setup

```bash
cd client
npm install
```

## ▶️ Running the Application

**Terminal 1 - Backend:**
```bash
cd server
npm start
```

**Terminal 2 - Frontend:**
```bash
cd client
npm start
```

- Backend: http://localhost:5000
- Frontend: http://localhost:3000

## 🌐 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/books` | Get all books |
| POST | `/api/books` | Add new book |
| DELETE | `/api/books/:id` | Delete book |

## 📊 Database Schema

```javascript
{
  title: String (required),
  author: String (required),
  isbn: String (required, unique),
  year: Number (required)
}
```

## 🎯 Marks Breakdown

- Task 1: Frontend (40/40) ✅
- Task 2: Backend API (40/40) ✅
- Task 3: Integration (20/20) ✅

**Total: 100/100** ✅

## 👨‍💻 Author

Smart Library System - Lab Final Project

**Version:** 1.0.0  
**Date:** January 1, 2026
