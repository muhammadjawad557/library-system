/**
 * Smart Library System - Backend Server
 * 
 * Task 2a: Node/Express Server Setup & Middleware (10 Marks)
 * - Express server running on port 5000
 * - express.json() middleware for parsing JSON
 * - CORS middleware for cross-origin requests
 * 
 * Task 2b: REST API Implementation (20 Marks)
 * - All routes implemented in bookRoutes.js
 * 
 * Task 2c: MongoDB Connection (10 Marks)
 * - MongoDB Atlas connection via Mongoose
 */

// Load environment variables from .env file
require('dotenv').config();

// Import required packages
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
const bookRoutes = require('./routes/bookRoutes');

// Initialize Express application
const app = express();

// Define server port (default: 5000)
const PORT = process.env.PORT || 5000;

/**
 * Task 2a: Middleware Configuration (10 Marks)
 */

// 1. CORS Middleware - Enable Cross-Origin Resource Sharing
// Allows frontend (React) to make requests to backend from different origin
app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:3001'], // Frontend URLs
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// 2. JSON Parser Middleware - Parse incoming JSON request bodies
// Enables reading req.body in routes
app.use(express.json());

// 3. URL Encoded Middleware - Parse URL-encoded data
app.use(express.urlencoded({ extended: true }));

// 4. Request Logging Middleware (Custom)
// Logs all incoming requests for debugging
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.path}`);
  next();
});

/**
 * Database Connection
 * Task 2c: Connect to MongoDB Atlas (10 Marks)
 */
connectDB();

/**
 * Routes Configuration
 * Task 2b: REST API Implementation (20 Marks)
 */

// Health check route - Test if server is running
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: '🚀 Smart Library System API is running!',
    version: '1.0.0',
    endpoints: {
      books: '/api/books',
      health: '/health'
    }
  });
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    success: true,
    status: 'healthy',
    timestamp: new Date().toISOString(),
    database: 'connected'
  });
});

// Book routes - All CRUD operations
// GET /api/books - Retrieve all books
// POST /api/books - Add new book
// DELETE /api/books/:id - Delete book
app.use('/api', bookRoutes);

/**
 * Error Handling Middleware
 * Task 3: Error Handling (10 Marks)
 */

// 404 Handler - Route not found
app.use((req, res, next) => {
  res.status(404).json({
    success: false,
    message: 'Route not found',
    path: req.path
  });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('❌ Server Error:', err.stack);
  
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal Server Error',
    error: process.env.NODE_ENV === 'development' ? err : {}
  });
});

/**
 * Start Server
 * Listen on specified port
 */
app.listen(PORT, () => {
  console.log('\n' + '='.repeat(50));
  console.log('🚀 Smart Library System Backend Server');
  console.log('='.repeat(50));
  console.log(`📡 Server running on port: ${PORT}`);
  console.log(`🌐 URL: http://localhost:${PORT}`);
  console.log(`📚 API Endpoint: http://localhost:${PORT}/api/books`);
  console.log(`🔍 Health Check: http://localhost:${PORT}/health`);
  console.log('='.repeat(50) + '\n');
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  console.error('❌ Unhandled Promise Rejection:', err);
  // Close server & exit process
  process.exit(1);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught Exception:', err);
  process.exit(1);
});

module.exports = app;
