/**
 * Book Routes - RESTful API Endpoints
 * 
 * Task 2b: REST API Implementation (20 Marks)
 * Implements all CRUD operations for book management:
 * - GET /api/books - Retrieve all books
 * - POST /api/books - Add a new book
 * - DELETE /api/books/:id - Remove a book by ID
 * 
 * Task 3: Error Handling (10 Marks)
 * All routes include try-catch blocks for proper error handling
 */

const express = require('express');
const router = express.Router();
const Book = require('../models/Book');

/**
 * @route   GET /api/books
 * @desc    Get all books from database
 * @access  Public
 * 
 * Returns all books sorted by creation date (newest first)
 */
router.get('/books', async (req, res) => {
  try {
    // Retrieve all books from MongoDB, sorted by creation date (newest first)
    const books = await Book.find().sort({ createdAt: -1 });
    
    // Send successful response with books array
    res.status(200).json(books);
    
    // Log successful retrieval
    console.log(`✅ Retrieved ${books.length} books from database`);
  } catch (error) {
    // Task 3: Error Handling with try-catch block
    console.error('❌ Error fetching books:', error.message);
    
    // Send user-friendly error response
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve books from database',
      error: error.message
    });
  }
});

/**
 * @route   POST /api/books
 * @desc    Add a new book to database
 * @access  Public
 * 
 * Expects JSON body with: title, author, isbn, year
 */
router.post('/books', async (req, res) => {
  try {
    // Extract book data from request body
    const { title, author, isbn, year } = req.body;
    
    // Validate required fields
    if (!title || !author || !isbn || !year) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields: title, author, isbn, year'
      });
    }
    
    // Check if book with same ISBN already exists
    const existingBook = await Book.findOne({ isbn });
    if (existingBook) {
      return res.status(400).json({
        success: false,
        message: 'A book with this ISBN already exists'
      });
    }
    
    // Create new book instance
    const newBook = new Book({
      title,
      author,
      isbn,
      year: parseInt(year) // Ensure year is a number
    });
    
    // Save book to MongoDB
    const savedBook = await newBook.save();
    
    // Send successful response with created book
    res.status(201).json({
      success: true,
      message: 'Book added successfully',
      data: savedBook
    });
    
    // Log successful creation
    console.log(`✅ New book added: ${savedBook.title}`);
  } catch (error) {
    // Task 3: Error Handling with try-catch block
    console.error('❌ Error adding book:', error.message);
    
    // Handle validation errors
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: messages
      });
    }
    
    // Handle duplicate key error (ISBN already exists)
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: 'A book with this ISBN already exists'
      });
    }
    
    // Send generic error response
    res.status(500).json({
      success: false,
      message: 'Failed to add book to database',
      error: error.message
    });
  }
});

/**
 * @route   DELETE /api/books/:id
 * @desc    Delete a book by ID
 * @access  Public
 * 
 * Removes book from database using MongoDB ObjectId
 */
router.delete('/books/:id', async (req, res) => {
  try {
    // Extract book ID from URL parameters
    const { id } = req.params;
    
    // Validate MongoDB ObjectId format
    if (!id.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid book ID format'
      });
    }
    
    // Find and delete book by ID
    const deletedBook = await Book.findByIdAndDelete(id);
    
    // Check if book was found
    if (!deletedBook) {
      return res.status(404).json({
        success: false,
        message: 'Book not found'
      });
    }
    
    // Send successful response
    res.status(200).json({
      success: true,
      message: 'Book deleted successfully',
      data: deletedBook
    });
    
    // Log successful deletion
    console.log(`✅ Book deleted: ${deletedBook.title}`);
  } catch (error) {
    // Task 3: Error Handling with try-catch block
    console.error('❌ Error deleting book:', error.message);
    
    // Send user-friendly error response
    res.status(500).json({
      success: false,
      message: 'Failed to delete book from database',
      error: error.message
    });
  }
});

/**
 * @route   GET /api/books/:id
 * @desc    Get a single book by ID
 * @access  Public
 * 
 * BONUS: Additional route for getting book details
 */
router.get('/books/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Validate MongoDB ObjectId format
    if (!id.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid book ID format'
      });
    }
    
    // Find book by ID
    const book = await Book.findById(id);
    
    // Check if book exists
    if (!book) {
      return res.status(404).json({
        success: false,
        message: 'Book not found'
      });
    }
    
    // Send successful response
    res.status(200).json({
      success: true,
      data: book
    });
  } catch (error) {
    console.error('❌ Error fetching book:', error.message);
    
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve book',
      error: error.message
    });
  }
});

/**
 * @route   PUT /api/books/:id
 * @desc    Update a book by ID
 * @access  Public
 * 
 * BONUS: Additional route for updating book details
 */
router.put('/books/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, author, isbn, year } = req.body;
    
    // Validate MongoDB ObjectId format
    if (!id.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid book ID format'
      });
    }
    
    // Find and update book
    const updatedBook = await Book.findByIdAndUpdate(
      id,
      { title, author, isbn, year },
      { new: true, runValidators: true }
    );
    
    // Check if book exists
    if (!updatedBook) {
      return res.status(404).json({
        success: false,
        message: 'Book not found'
      });
    }
    
    // Send successful response
    res.status(200).json({
      success: true,
      message: 'Book updated successfully',
      data: updatedBook
    });
    
    console.log(`✅ Book updated: ${updatedBook.title}`);
  } catch (error) {
    console.error('❌ Error updating book:', error.message);
    
    res.status(500).json({
      success: false,
      message: 'Failed to update book',
      error: error.message
    });
  }
});

module.exports = router;
