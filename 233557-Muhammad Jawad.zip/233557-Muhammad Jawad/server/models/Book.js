/**
 * Book Model - Mongoose Schema
 * 
 * Task 2c: MongoDB Schema Design (10 Marks)
 * Defines the structure of Book documents in MongoDB
 * 
 * Schema includes:
 * - title: Book title (required)
 * - author: Author name (required)
 * - isbn: International Standard Book Number (required, unique)
 * - year: Publication year (required)
 * - timestamps: Automatic createdAt and updatedAt fields
 */

const mongoose = require('mongoose');

/**
 * Book Schema Definition
 * Defines the structure and validation rules for book documents
 */
const bookSchema = new mongoose.Schema(
  {
    // Book Title
    title: {
      type: String,
      required: [true, 'Book title is required'],
      trim: true, // Removes whitespace from both ends
      minlength: [1, 'Title must be at least 1 character'],
      maxlength: [200, 'Title cannot exceed 200 characters']
    },

    // Author Name
    author: {
      type: String,
      required: [true, 'Author name is required'],
      trim: true,
      minlength: [1, 'Author name must be at least 1 character'],
      maxlength: [100, 'Author name cannot exceed 100 characters']
    },

    // ISBN Number (International Standard Book Number)
    isbn: {
      type: String,
      required: [true, 'ISBN is required'],
      unique: true, // Ensures no duplicate ISBN numbers
      trim: true,
      // ISBN validation: allows ISBN-10 and ISBN-13 formats
      validate: {
        validator: function(v) {
          // Remove hyphens and spaces for validation
          const cleanISBN = v.replace(/[-\s]/g, '');
          // Check if it's 10 or 13 digits
          return /^(\d{10}|\d{13})$/.test(cleanISBN);
        },
        message: 'ISBN must be a valid 10 or 13 digit number'
      }
    },

    // Publication Year
    year: {
      type: Number,
      required: [true, 'Publication year is required'],
      min: [1000, 'Year must be 1000 or later'],
      max: [new Date().getFullYear() + 1, 'Year cannot be in the future'],
      validate: {
        validator: Number.isInteger,
        message: 'Year must be a whole number'
      }
    }
  },
  {
    // Automatically add createdAt and updatedAt timestamps
    timestamps: true,
    
    // Customize JSON output
    toJSON: {
      virtuals: true,
      // Remove MongoDB internal fields from JSON output
      transform: function(doc, ret) {
        ret.id = ret._id;
        delete ret.__v;
        return ret;
      }
    }
  }
);

// Add text index on title and author for search functionality
// Note: isbn already has a unique index from the schema definition
bookSchema.index({ title: 'text', author: 'text' });

/**
 * Instance Methods
 */

// Get book summary
bookSchema.methods.getSummary = function() {
  return `${this.title} by ${this.author} (${this.year})`;
};

/**
 * Static Methods
 */

// Find books by author
bookSchema.statics.findByAuthor = function(author) {
  return this.find({ author: new RegExp(author, 'i') });
};

// Find books by year range
bookSchema.statics.findByYearRange = function(startYear, endYear) {
  return this.find({ year: { $gte: startYear, $lte: endYear } });
};

/**
 * Pre-save middleware
 * Runs before saving a document
 */
bookSchema.pre('save', function(next) {
  // Capitalize first letter of title and author
  if (this.isModified('title')) {
    this.title = this.title.charAt(0).toUpperCase() + this.title.slice(1);
  }
  if (this.isModified('author')) {
    this.author = this.author.charAt(0).toUpperCase() + this.author.slice(1);
  }
  next();
});

/**
 * Create and export Book model
 * This model will be used to perform CRUD operations on the books collection
 */
const Book = mongoose.model('Book', bookSchema);

module.exports = Book;
