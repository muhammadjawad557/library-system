/**
 * Database Configuration
 * MongoDB Atlas Connection using Mongoose
 * 
 * This file handles the connection to MongoDB Atlas cloud database.
 * It uses environment variables for secure credential storage.
 */

const mongoose = require('mongoose');

/**
 * Connect to MongoDB Atlas
 * @returns {Promise} MongoDB connection promise
 * 
 * Task 2c: MongoDB Connection (10 Marks)
 * - Connects to MongoDB Atlas using Mongoose
 * - Uses connection string from environment variables
 * - Implements error handling for connection issues
 */
const connectDB = async () => {
  try {
    // Connect to MongoDB Atlas using connection string from .env file
    const conn = await mongoose.connect(process.env.MONGODB_URI, {
      // These options ensure stable connection
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    // Log successful connection with host information
    console.log(`✅ MongoDB Atlas Connected: ${conn.connection.host}`);
    console.log(`📚 Database: ${conn.connection.name}`);
    
    return conn;
  } catch (error) {
    // Log detailed error information for debugging
    console.error('❌ MongoDB Connection Error:');
    console.error('Message:', error.message);
    
    // Exit process with failure code if connection fails
    // This prevents the server from running without database
    process.exit(1);
  }
};

// Handle connection events for monitoring

// Connection successful
mongoose.connection.on('connected', () => {
  console.log('🔗 Mongoose connected to MongoDB Atlas');
});

// Connection error
mongoose.connection.on('error', (err) => {
  console.error('❌ Mongoose connection error:', err);
});

// Connection disconnected
mongoose.connection.on('disconnected', () => {
  console.log('🔌 Mongoose disconnected from MongoDB Atlas');
});

// Handle application termination
process.on('SIGINT', async () => {
  await mongoose.connection.close();
  console.log('🛑 MongoDB connection closed due to app termination');
  process.exit(0);
});

module.exports = connectDB;
