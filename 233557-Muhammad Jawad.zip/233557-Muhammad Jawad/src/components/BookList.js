import React, { useState } from 'react';
import * as AlertDialog from '@radix-ui/react-alert-dialog';
import * as Separator from '@radix-ui/react-separator';
import { TrashIcon, ReaderIcon } from '@radix-ui/react-icons';
import './BookList.css';


const BookList = ({ books, onDeleteBook }) => {
  const [deleteBookId, setDeleteBookId] = useState(null);

  const handleDeleteClick = (bookId) => {
    setDeleteBookId(bookId);
  };

  const handleConfirmDelete = () => {
    if (deleteBookId) {
      onDeleteBook(deleteBookId);
      setDeleteBookId(null);
    }
  };

  if (books.length === 0) {
    return (
      <div className="book-list-container">
        <h2>
          <ReaderIcon className="header-icon" />
          Library Collection
        </h2>
        <Separator.Root className="separator-root" />
        <p className="no-books-message">
          No books in the library yet. Add some books to get started!
        </p>
      </div>
    );
  }

  return (
    <div className="book-list-container">
      <h2>
        <ReaderIcon className="header-icon" />
        Library Collection ({books.length} books)
      </h2>
      <Separator.Root className="separator-root" />
      
      <div className="book-grid">
        {books.map((book) => (
          <div key={book._id || book.isbn} className="book-card">
            <div className="book-card-header">
              <h3 className="book-title">{book.title}</h3>
            </div>
            <Separator.Root className="separator-root separator-card" />
            <div className="book-card-body">
              <p className="book-detail">
                <span className="label">Author:</span>
                <span className="value">{book.author}</span>
              </p>
              <p className="book-detail">
                <span className="label">ISBN:</span>
                <span className="value">{book.isbn}</span>
              </p>
              <p className="book-detail">
                <span className="label">Year:</span>
                <span className="value">{book.publicationYear}</span>
              </p>
            </div>
            <div className="book-card-footer">
              <AlertDialog.Root 
                open={deleteBookId === (book._id || book.isbn)}
                onOpenChange={(open) => !open && setDeleteBookId(null)}
              >
                <AlertDialog.Trigger asChild>
                  <button 
                    onClick={() => handleDeleteClick(book._id || book.isbn)}
                    className="delete-btn"
                  >
                    <TrashIcon className="btn-icon" />
                    Delete Book
                  </button>
                </AlertDialog.Trigger>
                <AlertDialog.Portal>
                  <AlertDialog.Overlay className="alert-overlay" />
                  <AlertDialog.Content className="alert-content">
                    <AlertDialog.Title className="alert-title">
                      Delete Book?
                    </AlertDialog.Title>
                    <AlertDialog.Description className="alert-description">
                      Are you sure you want to delete "{book.title}"?
                    </AlertDialog.Description>
                    <div className="alert-buttons">
                      <AlertDialog.Cancel asChild>
                        <button className="alert-btn alert-cancel">
                          Cancel
                        </button>
                      </AlertDialog.Cancel>
                      <AlertDialog.Action asChild>
                        <button 
                          className="alert-btn alert-delete"
                          onClick={handleConfirmDelete}
                        >
                          Yes, Delete
                        </button>
                      </AlertDialog.Action>
                    </div>
                  </AlertDialog.Content>
                </AlertDialog.Portal>
              </AlertDialog.Root>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BookList;
